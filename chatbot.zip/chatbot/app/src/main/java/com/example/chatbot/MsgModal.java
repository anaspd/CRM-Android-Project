package com.example.chatbot;

public class MsgModal {

    private String cnt;

    public String getCnt() {
        return cnt;
    }

    public void setCnt(String cnt) {
        this.cnt = cnt;
    }

    public MsgModal(String cnt) {
        this.cnt = cnt;
    }
}
